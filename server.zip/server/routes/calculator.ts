import { Router } from "express";
import OpenAI from "openai";
import multer from "multer";
import { z } from "zod";
import { userInteractions } from "@shared/schema";
import { db } from "../db";
import { checkFeatureAccess } from "../middleware/check-feature-access";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Configure multer and create router
const upload = multer({ storage: multer.memoryStorage() });
const router = Router();

// Add feature access check middleware
router.use(checkFeatureAccess("calculator"));

// Schema for calculation request
const calculationSchema = z.object({
  mode: z.enum(["basic", "text", "image"]),
  input: z.string().optional(),
});

router.post("/solve", upload.single("image"), async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { mode } = calculationSchema.parse({
      mode: req.body.mode,
      input: req.body.input
    });

    let result, steps, explanation;
    const systemPrompt = await getPersonalizedSystemPrompt(req.user.id);

    if (mode === "basic") {
      // Handle basic calculations using eval (with safety checks)
      const input = req.body.input.replace(/[^0-9+\-*/(). ]/g, "");
      if (!input) throw new Error("Invalid mathematical expression");

      result = eval(input).toString();
      steps = [`${input} = ${result}`];
    } else if (mode === "text") {
      // Use GPT-4 for text-based problems
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: `${systemPrompt}\nYou are also a math expert. Provide the solution with step-by-step explanation. Return the response in this JSON format: { result: string, steps: string[], explanation: string }`,
          },
          {
            role: "user",
            content: req.body.input,
          },
        ],
        response_format: { type: "json_object" },
      });

      if (response.choices[0].message.content) {
        const solution = JSON.parse(response.choices[0].message.content);
        ({ result, steps, explanation } = solution);

        // Store interaction for learning
        await db.insert(userInteractions).values({
          userId: req.user.id,
          prompt: req.body.input,
          response: JSON.stringify(solution),
          context: {
            type: "calculator",
            mode: "text",
            complexity: steps.length,
            hasExplanation: !!explanation
          },
          createdAt: new Date()
        });
      } else {
        throw new Error("Failed to get response from AI");
      }
    } else if (mode === "image" && req.file) {
      // Use GPT-4 Vision for image-based problems
      const base64Image = req.file.buffer.toString("base64");

      const response = await openai.chat.completions.create({
        model: "gpt-4-vision-preview",
        messages: [
          {
            role: "system",
            content: "You are a math expert. Analyze this image of a math problem and provide the solution with step-by-step explanation. Return the response in this JSON format: { result: string, steps: string[], explanation: string }",
          },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: {
                  url: `data:${req.file.mimetype};base64,${base64Image}`,
                },
              },
              {
                type: "text",
                text: "Solve this math problem and explain the steps.",
              },
            ],
          },
        ],
        max_tokens: 500,
      });

      if (response.choices[0].message.content) {
        const solution = JSON.parse(response.choices[0].message.content);
        ({ result, steps, explanation } = solution);
      } else {
        throw new Error("Failed to get response from AI");
      }
    }

    res.json({ result, steps, explanation });
  } catch (error: any) {
    console.error("Calculator error:", error);
    res.status(400).json({ error: error.message });
  }
});

export default router;