import { Router } from "express";
import { z } from "zod";
import { db } from "../db";
import { 
  learningChallenges,
  userProgress,
  userAchievements,
  insertLearningChallengeSchema
} from "@shared/schema";
import { eq, and } from "drizzle-orm";
import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const router = Router();

// Get all active challenges for the user
router.get("/", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const challenges = await db
      .select()
      .from(learningChallenges)
      .where(
        and(
          eq(learningChallenges.userId, req.user.id),
          eq(learningChallenges.status, "active")
        )
      );

    res.json(challenges);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Generate a new personalized challenge
router.post("/generate", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    // Get user's learning patterns and progress
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, req.user.id));

    // Generate challenge using AI
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a personalized learning challenge generator. Create an engaging educational challenge based on the user's level (${progress?.level || 1}) and learning history. The challenge should be adaptive and appropriate for their skill level. Return the response in this JSON format:
          {
            "title": string,
            "description": string,
            "type": "quiz" | "project" | "research",
            "difficulty": "beginner" | "intermediate" | "advanced" | "expert",
            "points": number (100-1000),
            "requirements": object (specific completion criteria),
            "aiPrompt": string (helpful guidance)
          }`
        }
      ],
      response_format: { type: "json_object" },
    });

    if (!response.choices[0].message.content) {
      throw new Error("Failed to generate challenge");
    }

    const challenge = JSON.parse(response.choices[0].message.content);

    // Create the challenge in database
    const [newChallenge] = await db
      .insert(learningChallenges)
      .values({
        userId: req.user.id,
        ...challenge,
        status: "active",
        deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      })
      .returning();

    res.json(newChallenge);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Complete a challenge
router.post("/:id/complete", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const challengeId = parseInt(req.params.id);

    // Get the challenge
    const [challenge] = await db
      .select()
      .from(learningChallenges)
      .where(
        and(
          eq(learningChallenges.id, challengeId),
          eq(learningChallenges.userId, req.user.id)
        )
      );

    if (!challenge) {
      return res.status(404).json({ message: "Challenge not found" });
    }

    if (challenge.status !== "active") {
      return res.status(400).json({ message: "Challenge is not active" });
    }

    // Update challenge status
    await db
      .update(learningChallenges)
      .set({
        status: "completed",
        completedAt: new Date(),
      })
      .where(eq(learningChallenges.id, challengeId));

    // Update user progress
    await db
      .update(userProgress)
      .set({
        experiencePoints: progress.experiencePoints + challenge.points,
        level: Math.floor((progress.experiencePoints + challenge.points) / 1000) + 1,
        updatedAt: new Date(),
      })
      .where(eq(userProgress.userId, req.user.id));

    // Check for achievements
    const completedChallenges = await db
      .select()
      .from(learningChallenges)
      .where(
        and(
          eq(learningChallenges.userId, req.user.id),
          eq(learningChallenges.status, "completed")
        )
      );

    // Award achievements based on milestones
    if (completedChallenges.length === 1) {
      await db.insert(userAchievements).values({
        userId: req.user.id,
        title: "First Challenge",
        description: "Completed your first learning challenge",
        type: "milestone",
        icon: "🎯",
      });
    } else if (completedChallenges.length === 10) {
      await db.insert(userAchievements).values({
        userId: req.user.id,
        title: "Challenge Master",
        description: "Completed 10 learning challenges",
        type: "milestone",
        icon: "🏆",
      });
    }

    res.json({ message: "Challenge completed successfully" });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Get user progress and achievements
router.get("/progress", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, req.user.id));

    const achievements = await db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userId, req.user.id));

    res.json({ progress, achievements });
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
