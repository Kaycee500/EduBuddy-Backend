import { Router } from "express";
import OpenAI from "openai";
import { z } from "zod";
import { checkFeatureAccess } from "../middleware/check-feature-access";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const router = Router();

// Add feature access check middleware - fix the middleware registration
router.use(checkFeatureAccess("writer"));

// Schema for humanization request
const humanizeSchema = z.object({
  content: z.string().min(1),
  style: z.enum(["academic", "casual", "professional", "creative"]),
  format: z.enum(["essay", "letter", "article", "report"]),
});

router.post("/humanize", async (req, res) => {
  try {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { content, style, format } = humanizeSchema.parse(req.body);

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: `You are a skilled writer specializing in ${style} ${format}s. Your task is to rewrite the given text to:
          1. Make it sound naturally human-written
          2. Ensure it passes plagiarism checks
          3. Maintain readability and coherence
          4. Keep the original meaning and key points
          5. Adapt to the ${style} style

          Respond with JSON in this format: 
          {
            "content": "rewritten text",
            "readabilityScore": number (0-100),
            "uniquenessScore": number (0-100)
          }`
        },
        {
          role: "user",
          content
        }
      ],
      response_format: { type: "json_object" },
    });

    if (!response.choices[0].message.content) {
      throw new Error("Failed to get response from AI");
    }

    const result = JSON.parse(response.choices[0].message.content);
    res.json(result);
  } catch (error: any) {
    console.error("Writer error:", error);
    res.status(400).json({ error: error.message });
  }
});

export default router;