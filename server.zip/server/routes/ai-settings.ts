import { Router } from "express";
import { z } from "zod";
import { db } from "../db";
import { aiPersonalizationSettings, insertAiPersonalizationSchema } from "@shared/schema";
import { eq } from "drizzle-orm";

const router = Router();

// Get user's AI settings
router.get("/", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const [settings] = await db
      .select()
      .from(aiPersonalizationSettings)
      .where(eq(aiPersonalizationSettings.userId, req.user.id));

    res.json(settings || null);
  } catch (error: any) {
    res.status(500).json({ message: error.message });
  }
});

// Update or create user's AI settings
router.post("/", async (req, res) => {
  if (!req.isAuthenticated()) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    const data = insertAiPersonalizationSchema.parse({
      ...req.body,
      userId: req.user.id,
    });

    const [settings] = await db
      .insert(aiPersonalizationSettings)
      .values(data)
      .onConflictDoUpdate({
        target: [aiPersonalizationSettings.userId],
        set: {
          learningStyle: data.learningStyle,
          interestAreas: data.interestAreas,
          communicationStyle: data.communicationStyle,
          difficultyPreference: data.difficultyPreference,
          updatedAt: new Date(),
        },
      })
      .returning();

    res.json(settings);
  } catch (error: any) {
    res.status(400).json({ message: error.message });
  }
});

export default router;
