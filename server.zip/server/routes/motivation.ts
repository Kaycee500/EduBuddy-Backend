import { Router } from "express";
import OpenAI from "openai";
import { z } from "zod";
import { db } from "../db";
import { 
  motivationTracking,
  userProgress,
  learningHistory,
  type MotivationTracking
} from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const router = Router();

// Get motivation status and personalized boost
router.get("/status", async (req, res) => {
  try {
    // Use default pro user id=1 since we're skipping auth
    const userId = 1;

    // Get user's motivation tracking data with proper null checks
    const [tracking] = await db
      .select()
      .from(motivationTracking)
      .where(eq(motivationTracking.userId, userId));

    // Get recent learning history
    const recentHistory = await db
      .select()
      .from(learningHistory)
      .where(eq(learningHistory.userId, userId))
      .orderBy(desc(learningHistory.createdAt))
      .limit(5);

    // Get user progress
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(eq(userProgress.userId, userId));

    // Default values for new users
    const defaultTracking = {
      userId: userId,
      engagementScore: 50,
      lastActivityType: "none",
      consecutiveDays: 0,
      learningStreak: 0,
      personalizedTips: [],
      lastMotivationBoost: new Date(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    // Generate personalized motivation boost if needed
    if (!tracking || shouldGenerateNewBoost(tracking)) {
      try {
        let boost;
        try {
          boost = await generateMotivationBoost(
            userId,
            progress,
            recentHistory
          );
        } catch (error) {
          console.error("OpenAI API error:", error);
          // Enhanced fallback content with more personalization
          boost = {
            message: `Keep pushing forward! Every step counts on your learning journey.`,
            tips: [
              {
                area: "consistency",
                tip: "Try to maintain a regular study schedule - even 15 minutes daily makes a difference."
              },
              {
                area: "progress",
                tip: "Break down your learning goals into smaller, manageable tasks."
              }
            ]
          };
        }

        // Update or create motivation tracking with proper null handling
        const [updatedTracking] = await db
          .insert(motivationTracking)
          .values({
            ...defaultTracking,
            engagementScore: calculateEngagementScore(recentHistory),
            lastActivityType: recentHistory[0]?.topic || "none",
            personalizedTips: boost.tips,
            lastMotivationBoost: new Date(),
          })
          .onConflictDoUpdate({
            target: [motivationTracking.userId],
            set: {
              engagementScore: calculateEngagementScore(recentHistory),
              lastActivityType: recentHistory[0]?.topic || "none",
              personalizedTips: boost.tips,
              lastMotivationBoost: new Date(),
              updatedAt: new Date(),
            },
          })
          .returning();

        return res.json({
          tracking: updatedTracking,
          boost: boost.message,
          needsBoost: true,
        });
      } catch (error) {
        console.error("Database error:", error);
        return res.status(500).json({ 
          message: "Failed to update motivation tracking",
          tracking: tracking || defaultTracking,
          needsBoost: false
        });
      }
    }

    return res.json({
      tracking: tracking || defaultTracking,
      needsBoost: false,
    });
  } catch (error: any) {
    console.error("Motivation status error:", error);
    res.status(500).json({ message: error.message });
  }
});

// Update streak and engagement with proper null handling
router.post("/update-streak", async (req, res) => {
  try {
    // Use default pro user id=1 since we're skipping auth
    const userId = 1;

    const [tracking] = await db
      .select()
      .from(motivationTracking)
      .where(eq(motivationTracking.userId, userId));

    if (!tracking) {
      // Create new tracking if it doesn't exist
      const [newTracking] = await db
        .insert(motivationTracking)
        .values({
          userId: userId,
          engagementScore: 50,
          lastActivityType: "none",
          consecutiveDays: 1,
          learningStreak: 1,
          lastMotivationBoost: new Date(),
          updatedAt: new Date(),
        })
        .returning();
      return res.json(newTracking);
    }

    const lastUpdate = tracking.updatedAt || new Date();
    const now = new Date();
    const hoursSinceLastUpdate = (now.getTime() - lastUpdate.getTime()) / (1000 * 60 * 60);

    const newStreak = tracking.learningStreak || 0;
    const consecutiveDays = tracking.consecutiveDays || 0;

    let updatedStreak = newStreak;
    let updatedConsecutiveDays = consecutiveDays;

    if (hoursSinceLastUpdate <= 24) {
      updatedStreak += 1;
      if (hoursSinceLastUpdate >= 20) { // New day threshold
        updatedConsecutiveDays += 1;
      }
    } else {
      updatedStreak = 1;
      updatedConsecutiveDays = 1;
    }

    const [updatedTracking] = await db
      .update(motivationTracking)
      .set({
        learningStreak: updatedStreak,
        consecutiveDays: updatedConsecutiveDays,
        updatedAt: now,
      })
      .where(eq(motivationTracking.userId, userId))
      .returning();

    res.json(updatedTracking);
  } catch (error: any) {
    console.error("Update streak error:", error);
    res.status(500).json({ message: error.message });
  }
});

// Helper functions remain unchanged
function shouldGenerateNewBoost(tracking: MotivationTracking): boolean {
  if (!tracking.lastMotivationBoost) return true;

  const hoursSinceLastBoost = 
    (new Date().getTime() - tracking.lastMotivationBoost.getTime()) / (1000 * 60 * 60);

  return hoursSinceLastBoost >= 4; // Generate new boost every 4 hours
}

function calculateEngagementScore(history: any[]): number {
  if (history.length === 0) return 50; // Default score

  const weights = {
    completion: 0.4,
    timeSpent: 0.3,
    engagement: 0.3,
  };

  return Math.min(100, Math.max(0, Math.round(
    history.reduce((score, activity) => {
      const completionScore = activity.completionStatus === "completed" ? 100 : 
        activity.completionStatus === "in_progress" ? 50 : 25;

      const timeScore = Math.min(100, (activity.timeSpent / 30) * 100); // 30 minutes as baseline
      const engagementScore = activity.engagement * 20; // Convert 1-5 to 20-100

      return score + (
        completionScore * weights.completion +
        timeScore * weights.timeSpent +
        engagementScore * weights.engagement
      );
    }, 0) / history.length
  )));
}

async function generateMotivationBoost(
  userId: number,
  progress: any,
  history: any[]
): Promise<{ message: string; tips: any[] }> {
  const response = await openai.chat.completions.create({
    model: "gpt-4o",
    messages: [
      {
        role: "system",
        content: `You are an AI learning motivation coach. Analyze the user's learning patterns and generate personalized motivation messages and tips. Keep the tone encouraging but not overly cheerful. Focus on genuine progress and growth mindset. Return response in this JSON format:
        {
          "message": "Main motivation message",
          "tips": [
            {
              "area": "learning strategy",
              "tip": "Specific actionable advice"
            }
          ]
        }`
      },
      {
        role: "user",
        content: JSON.stringify({
          level: progress?.level || 1,
          experiencePoints: progress?.experiencePoints || 0,
          recentActivities: history,
          learningStreak: progress?.streakDays || 0,
        })
      }
    ],
    response_format: { type: "json_object" },
  });

  if (!response.choices[0].message.content) {
    throw new Error("Failed to generate motivation boost");
  }

  return JSON.parse(response.choices[0].message.content);
}

export default router;