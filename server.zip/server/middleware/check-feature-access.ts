import { Request, Response, NextFunction } from "express";
import { db } from "../db";
import { featureUsage, users } from "@shared/schema";
import { eq, and } from "drizzle-orm";

const FREE_TRIAL_LIMIT = 5;

export function checkFeatureAccess(feature: string) {
  return async (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Timer is always available for free users
    if (feature === "timer") {
      return next();
    }

    const user = req.user;

    // Pro and Enterprise users have full access
    if (user.subscription === "pro" || user.subscription === "enterprise") {
      return next();
    }

    // Free users have limited access
    if (user.subscription === "free") {
      // Check usage count
      const [usage] = await db
        .select()
        .from(featureUsage)
        .where(
          and(
            eq(featureUsage.userId, user.id),
            eq(featureUsage.feature, feature)
          )
        );

      if (!usage) {
        // First time using the feature
        await db.insert(featureUsage).values({
          userId: user.id,
          feature,
          usageCount: 1,
        });
        return next();
      }

      const currentUsage = usage.usageCount ?? 0;
      if (currentUsage >= FREE_TRIAL_LIMIT) {
        return res.status(403).json({
          message: "Free trial limit reached. Please upgrade to continue using this feature.",
          limit: FREE_TRIAL_LIMIT,
          usage: currentUsage,
        });
      }

      // Increment usage count
      await db
        .update(featureUsage)
        .set({ 
          usageCount: currentUsage + 1,
          lastUsed: new Date()
        })
        .where(eq(featureUsage.id, usage.id));

      return next();
    }

    // Invalid subscription type
    return res.status(403).json({ message: "Invalid subscription type" });
  };
}